// Empty PostCSS config to prevent parent config from being used
export default {
  plugins: [],
};
